<!DOCTYPE html>
<html>
    <head>
          <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
        
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel=stylesheet type="text/css" href="common/common.css">
<link rel=stylesheet type="text/css" href="contact/contact.css">
           <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet"> 
           <script
  src="https://code.jquery.com/jquery-3.3.1.js"></script>
        
  
    </head>
<body class="contact">
        <div class="se-pre-con"></div>
    <!--topnavi-->
    <?php include 'common/menu.php';?>

<!--navigation-end-->


<!-- s: content area-->
<div class="conbg">
    <h1>Get in touch</h1>
    <p>You are just little away from reaching us</p>
    <img src="contact/images/conbg.jpg"></div>
  <div class="cont_con">
    
          <div class="con1">
                <h2>Contact us</h2>
    <div class="phem"><div class="citem"><img src="contact/images/phonew.svg"><p>9498448334</p></div>
              
               <div class="citem mailsh"><img src="contact/images/emailw.svg"><p >theempoweracademy.tea@gmail.com</p></div>
              </div>
               <div class="citem"><img src="contact/images/locw.svg"><p>No 1, GST Road, Alandur-St Thomas Mount, Chennai - 600016, Near RTO Office</p></div>
              
                  <div class="map"> <iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d3887.493503429984!2d80.2003991148223!3d13.00421469083455!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e3!4m0!4m5!1s0x3a5267443ee64173%3A0x66560d01ddcff2c!2sRegional+Transport+Office%2C+Municipal+Commercial+Building+Complex%2C+Meenambakkam%2C+1st+Floor%2C+New+Street%2C+Mela+Ilandaikulam%2C+Alandur%2C+Chennai%2C+Tamil+Nadu+600016!3m2!1d13.004214699999999!2d80.2025878!5e0!3m2!1sen!2sin!4v1524968007725" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
              
              
    </div>
      
       <div class="con2">
           <h2>Kindly the drop your queries, we get back to you.</h2>
    <div class="swit">
           <div class="swit1"><img src="contact/images/general.svg"><p class="switp" >General</p></div>
         <div class="swit1"><img src="contact/images/tour.svg"><p class="switp" >Tour</p></div>
         <div class="swit1"><img src="contact/images/car.svg"><p class="switp" >RAC</p></div>
         <div class="swit1"><img src="contact/images/airport.svg"><p class="switp" >Pickup</p></div>
           
           </div>
           
           <div class="form">
           <div class="form_cont">
   
      
           <form name="Contact us form" id="cont_form" action="https://formspree.io/theempoweracademy.tea@gmail.com"
      method="POST">
                 <input type="hidden" name="_next" value="https://www.theempoweracademy.in/theempoweracademy.tea@gmail.com" />
               
                 <div class="fields">
            <div class="set12">
           <div  class="set1">
            
       
      
               
    <div id="cletf1"><input type="text" name="name" placeholder="Name" required > </div>
               <div  id="cletf3"><input type="email" name="Email-id" placeholder="Email ID" required></div>
       
     
               </div>
               
        <div class="set2">    
            
        
             <div  id="cletf2"><input type="tel" name="Phone" placeholder="Phone number" required></div>
            
                 <div id="cletf4"><input type="text" name="name" placeholder="Organistaion name" required > </div>
            </div>
            </div>
            <div class="set3">
            
                  <div  id="clet5"><textarea  name="comment"  placeholder="Drop your queries here.."></textarea></div>
            
            <div  id="cletf6"><input id="ffsubmit" type="submit" name="Buy new machine" value="Submit"></div>
              
                </div>
    </div>
              </form>
            
            
            </div>
               
               
               
               
               
               
               <div class="form_cont">
   
      
           <form name="Contact us form" id="cont_form" action="https://formspree.io/fardeenqureshi@hotmail.com"
      method="POST">
                 <input type="hidden" name="_next" value="https://www.chineselasers.com/misc/cform/cform.html" />
               
                 <div class="fields">
            <div class="set12">
           <div  class="set1">
            
       
      
               
    <div id="cletf1"><input type="text" name="name" placeholder="Name" required > </div>
               <div  id="cletf3"><input type="email" name="Email-id" placeholder="Email ID" required></div>
       
     
               </div>
               
        <div class="set2">    
            
        
             <div  id="cletf2"><input type="tel" name="Phone" placeholder="Phone number" required></div>
            
                 <div id="cletf4"><input type="text" name="name" placeholder=" location" required > </div>
            </div>
            </div>
            <div class="set3">
            
                  <div  id="clet5"><textarea  name="comment" placeholder="Drop your queries here.."></textarea></div>
            
            <div  id="cletf6"><input id="ffsubmit" type="submit" name="Repair" value="Submit"></div>
              
                </div>
    </div>
              </form>
            
            
            </div>
               
               
               <div class="form_cont">
   
      
           <form name="Contact us form" id="cont_form" action="https://formspree.io/fardeenqureshi@hotmail.com"
      method="POST">
                 <input type="hidden" name="_next" value="https://www.chineselasers.com/misc/cform/cform.html" />
               
                 <div class="fields">
            <div class="set12">
           <div  class="set1">
            
       
      
               
    <div id="cletf1"><input type="text" name="name" placeholder="Name" required > </div>
               <div  id="cletf3"><input type="email" name="Email-id" placeholder="Email ID" required></div>
       
     
               </div>
               
        <div class="set2">    
            
        
             <div  id="cletf2"><input type="tel" name="Phone" placeholder="Phone number" required></div>
            
                 <div id="cletf4"><input type="text" name="name" placeholder="location" required > </div>
            </div>
            </div>
            <div class="set3">
            
                  <div  id="clet5"><textarea  name="comment"  placeholder="Drop your queries here..
                      "></textarea></div>
            
            <div  id="cletf6"><input id="ffsubmit" type="submit" name="Rental" value="Submit"></div>
              
                </div>
    </div>
              </form>
            
            
            </div>
               
               <div class="form_cont">
   
      
           <form name="Contact us form" id="cont_form" action="https://formspree.io/fardeenqureshi@hotmail.com"
      method="POST">
                 <input type="hidden" name="_next" value="https://www.chineselasers.com/misc/cform/cform.html" />
               
                 <div class="fields">
            <div class="set12">
           <div  class="set1">
            
       
      
               
    <div id="cletf1"><input type="text" name="name" placeholder="Name" required > </div>
               <div  id="cletf3"><input type="email" name="Email-id" placeholder="Email ID" required></div>
       
     
               </div>
               
        <div class="set2">    
            
        
             <div  id="cletf2"><input type="tel" name="Phone" placeholder="Phone number" required></div>
            
                 <div id="cletf4"><input type="text" name="name" placeholder="location" required > </div>
            </div>
            </div>
            <div class="set3">
            
                  <div  id="clet5"><textarea  name="comment" placeholder="Drop your queries here..
                      "></textarea></div>
            
            <div  id="cletf6"><input id="ffsubmit" type="submit" name="Buyback" value="Submit"></div>
              
                </div>
    </div>
              </form>
            
            
            </div>
               
               
               
               
               
               
           
           </div>
    </div>
    </div>
    <!-- e: content area-->
    <!-- s: Footer-->
    

   
   <?php include 'footer.php';?>
    
        <!-- e: Footer-->
           
    
 
        <!-- e: Footer-->
    <script src="common/common.js" type="text/javascript"></script>
    <script src="contact/contact.js" type="text/javascript"></script>
    </body>