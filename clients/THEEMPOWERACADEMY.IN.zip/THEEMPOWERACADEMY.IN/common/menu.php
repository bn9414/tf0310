
    <!--topnavi-->
  <!--    <div class="se-pre-con"></div>-->
    <div class="top-nav">
        <div class="lft-prt">
            <a href="#"><img src="common/images/phone.svg">94984 48334</a>
            <a href="#"><img src="common/images/envp.svg"> theempoweracademy.tea@gmail.com</a>
        </div>
        <div class="rgt-prt">
            <a href="https://www.facebook.com/Melvin-Logistics-2075156859427659/"><img src="common/images/fac.svg"></a>
            <a href="#"><img src="common/images/twt.svg"></a>
            <a href="#"><img src="common/images/in.svg"></a>
            <a href="https://www.instagram.com/melvin_logistics/"><img src="common/images/insta.svg"></a>
        </div>
    </div>
    <!--topnavi-->
<!--navigation-->
  <div class="web-nav">
      <div class="lobrand">
      <img class="brimg" src="common/images/logo.svg">
      </div>
      <div class="weblinks aalnk">
          
         <a class="aclr home1" href="index.php">HOME </a>
        <a class="aclr about1" href="about.php">ABOUT</a>
          <div class="posv">
        <div class="houpsc aclr upsc1" href="upsc.php">UPSC
            </div>
              <div class="hovmnu">
        <a class="btmbr" href="abt.php">About </a>
        <a class="btmbr" href="course.php">Course Offered</a>
        <a class="btmbr" href="batch.php">Batch Timing </a>
        <a  class="btmbr" href="fee.php">Fee Structure</a>
        <a href="policy.php">Analysis</a>
      </div>
        </div>
           <div class="posv">
        <div class="houpsc1  aclr tnpc1" href="tnpc.php">TNPC
            </div>
              <div class="hovmnu1 ">
        <a class="btmbr" href="tnpcabt.php">About </a>
        <a class="btmbr" href="course.php">Course Offered</a>
        <a class="btmbr" href="batch.php">Batch Timing </a>
        <a  class="btmbr" href="fee.php">Fee Structure</a>
        <a href="policy.php">Analysis</a>
      </div>
        </div>
       <!-- <a class="aclr" href="#">TNPC</a>-->
        <a  class="aclr current1" href="current.php">CURRENT AFFAIRS</a>
        <a class="aclr contact1" href="contact.php">CONTACT US</a>
      </div>
      
      
      
      <div class="moblinks aalnk">
        <a class="mnnnu home1" href="index.php">HOME </a>
        <a class="mnnnu about1" href="about.php">ABOUT</a>
        <div class="mnnnu ace upsc1"  href="upsc.php">UPSC <i id="mmn" class="fa fa-chevron-down dwn dwn1" aria-hidden="true"></i>
        
          </div>
          <div class="emew">
           <a class="drp" href="about.php">About</a>
          <a  class="drp" href="course.php">Course Offered</a>
               <a  class="drp" href="batch.php">Batch Timing</a>
              <a  class="drp" href="fee.php">Fee Structure</a>
               <a  class="drp" href="policy.php">Analysis</a>
          </div>
          <div class="mnnnu ace tnpc1"  href="tnpc.php">TNPC <i id="mmn1" class="fa fa-chevron-down dwn dwn1" aria-hidden="true"></i>
        
          </div>
          <div class="emew1">
           <a class="drp" href="tnpcabt.php">About</a>
          <a  class="drp" href="course.php">Course Offered</a>
               <a  class="drp" href="batch.php">Batch Timing</a>
              <a  class="drp" href="fee.php">Fee Structure</a>
               <a  class="drp" href="policy.php">Analysis</a>
          </div>
        <a class="mnnnu current1" href="current.php">CURRENT AFFAIRS</a>
        <a  class="mnnnu contact1" href="contact.php">CONTACT US</a>
      </div>
      
      
<div class="bar-con" onclick="myFunction(this)">
  <div class="bar1"></div>
  <div class="bar2"></div>
  <div class="bar3"></div>
</div>
      

    </div>

<!--navigation-end-->
    
   