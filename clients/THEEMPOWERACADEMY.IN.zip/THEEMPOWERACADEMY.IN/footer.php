<!-- s: Footer-->
    

   
    <div class="footer">
  <div class="foot_con">
        <div class="foot1">
    <img src="common/images/logo.svg" alt="LOGO">
        <p>The Empower Academy is an institute for civil service exam.
</p>
   
      
      </div>
        
           <a href="https://goo.gl/maps/JQS6xkjsnmA2"  class="foot2" target="_blank">
     
        <img src="common/images/map.svg">
            <p>No 1, GST Road, Alandur-St Thomas Mount, Chennai - 600016, Near RTO Office</p>
      </a>
        <div class="foot3">
      <h2>Connect with us</h2>
            <div class="fooico">
            <a href="" target="_blank"><img src="common/images/fb32.svg"></a>
            <a  href="#" target="_blank"><img src="common/images/tw32.svg"></a>
            <a  href="" target="_blank"><img src="common/images/in32.svg"></a>
                    <a  href="#" target="_blank"><img src="common/images/link.svg"></a>
            </div>
      </div>
 
         <div class="copyright"><p>&copy; The Empower Academy 2018. All rights reserved</p></div>
        </div>
        
     </div>
    
        <!-- e: Footer-->