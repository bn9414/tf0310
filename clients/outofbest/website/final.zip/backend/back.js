var mnu = document.getElementsByClassName('mnu');
var title = document.getElementsByClassName('title');

mnu[0].addEventListener('click',function(){
        form1(0)
    },false);
    
mnu[1].addEventListener('click',function(){
        form1(1)
    },false);

mnu[2].addEventListener('click',function(){
        form1(2)
    },false);

mnu[3].addEventListener('click',function(){
        form1(3)
    },false);

mnu[4].addEventListener('click',function(){
        form1(4)
    },false);

mnu[5].addEventListener('click',function(){
        form1(5)
    },false);
    
mnu[6].addEventListener('click',function(){
        form1(6)
    },false);

mnu[7].addEventListener('click',function(){
        form1(7)
    },false);

mnu[8].addEventListener('click',function(){
        form1(8)
    },false);

mnu[9].addEventListener('click',function(){
        form1(9)
    },false);

mnu[10].addEventListener('click',function(){
        form1(10)
    },false);
    
mnu[11].addEventListener('click',function(){
        form1(11)
    },false);

mnu[12].addEventListener('click',function(){
        form1(12)
    },false);

mnu[13].addEventListener('click',function(){
        form1(13)
    },false);

mnu[14].addEventListener('click',function(){
        form1(14)
    },false);

mnu[15].addEventListener('click',function(){
        form1(15)
    },false);
    
mnu[16].addEventListener('click',function(){
        form1(16)
    },false);

mnu[17].addEventListener('click',function(){
        form1(17)
    },false);

mnu[18].addEventListener('click',function(){
        form1(18)
    },false);

mnu[19].addEventListener('click',function(){
        form1(19)
    },false);

mnu[20].addEventListener('click',function(){
        form1(20)
    },false);

mnu[21].addEventListener('click',function(){
        form1(21)
    },false);

mnu[22].addEventListener('click',function(){
        form1(22)
    },false);

mnu[23].addEventListener('click',function(){
        form1(23)
    },false);

mnu[24].addEventListener('click',function(){
        form1(24)
    },false);
    
mnu[25].addEventListener('click',function(){
        form1(25)
    },false);

mnu[26].addEventListener('click',function(){
        form1(26)
    },false);

mnu[27].addEventListener('click',function(){
        form1(27)
    },false);

mnu[28].addEventListener('click',function(){
        form1(28)
    },false);

mnu[29].addEventListener('click',function(){
        form1(29)
    },false);
    
mnu[30].addEventListener('click',function(){
        form1(30)
    },false);
 

function form1(e){
    var fomocon = document.getElementsByClassName('fomcon');
    if(e == 0){
        document.getElementsByTagName("form")[0].setAttribute("action", "adi.php");
    
        title[0].innerText="shopping ";
    }
    
    
    if(e == 1){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_onlinemoney.php");
        title[0].innerText="online money making ";
    }
    
    
    if(e == 2){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_moviebook.php");
        title[0].innerText="moving booking ";
    }
    
    
    if(e == 3){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_jobsearch.php");
        title[0].innerText="job search";
    }
    
    
    if(e == 4){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_travelbook.php");
        
        title[0].innerText="travel book ";
    }
    
    
    if(e == 5){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_webhost.php");
    title[0].innerText="web host";
    }
    
    
    if(e == 6){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_onlinefood.php");
        title[0].innerText="online food";
    }
    
    
    if(e == 7){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_onlineeducation.php");
        title[0].innerText="online education";
        
    }
    
    
    if(e == 8){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_newschannel.php");
        title[0].innerText="news channel ";
    }
    
    
    if(e == 9){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_logomakers.php");
        title[0].innerText="logo makers";
        
    }
    
    
    
    if(e == 10){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "frm_coupon.php");
        title[0].innerText="coupon";
    }
    
    
    
    if(e == 11){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "domainname.php");
        title[0].innerText="domain name";
    }
    
    
    
    if(e == 12){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "internationalreal.php");
        title[0].innerText="international real estate";
    }
    
    
    
    if(e == 13){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "currentaffairs.php");
        title[0].innerText="current affairs";
    }
    
    
    
    if(e == 14){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "onlinemusic.php");
        title[0].innerText="online music";
    }
    
    
    
    if(e == 15){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "sports.php");
        title[0].innerText="sports";
    }
    
    
    
    if(e == 16){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "matrimonial.php");
        title[0].innerText="matrimonial";
    }
    
    
    
    if(e == 17){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "dating.php");
        title[0].innerText="dating";
    }
    
    
    
    if(e == 18){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "kids.php");
        title[0].innerText="kids";
    }
    
    
    
    if(e == 19){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "onlinefurniture.php");
        title[0].innerText="online furniture";
    }
    
    
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "realestate.php");
        title[0].innerText="real estate";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "secondhand.php");
        title[0].innerText="second hand";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "socialmedia.php");
        title[0].innerText="social media";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "technologynews.php");
        title[0].innerText="technology news";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "stockbroker.php");
        title[0].innerText="stock broker";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "homeservice.php");
        title[0].innerText="home service";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "businessconsulting.php");
        title[0].innerText="busness consulting ";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "horoscope.php");
        title[0].innerText="horoscope";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "government.php");
        title[0].innerText="government ";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "lifeinsurance.php");
        title[0].innerText="life insurance";
    }
    
      
    
    if(e == 20){
        
        document.getElementsByTagName("form")[0].setAttribute("action", "healthinsurance.php");
        title[0].innerText="health insurance";
    }
    
    
    
    
    
}