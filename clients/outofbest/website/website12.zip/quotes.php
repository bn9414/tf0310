<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Out Of Best</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">

          <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
        
       
 <link rel=stylesheet type="text/css" href="bootstrap/bootstrap.min.css">
<link rel=stylesheet type="text/css" href="bootstrap/style.css">

<link rel=stylesheet type="text/css" href="main/main.css">
<link rel=stylesheet type="text/css" href="vendor.css">
<link rel=stylesheet type="text/css" href="quotes/quotes.css">


<link rel=stylesheet type="text/css" href="common/common.css">
<link rel=stylesheet type="text/scss" href="common/_responsive.scss">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    
<link rel=stylesheet type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    </head>
<body class="page-template-portfolio ish-content-overlay-large ish-blurred ish-color14 ish-no-blur">
    <div class="ish-blurred-overlay" style="display: none;"></div>
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
    
    
<div class="slider-con">
        <div class="ban"><img id="bimg" src="quotes/images/bb1.jpg"  id="ban1">
        <!--<div class="butbox"><a class="qut"  href="#" >Get a quote</a><a href="wedding_index.html" class="read">Read more</a></div>-->
           <div class="sidebg"></div>
   <h2 class="hdtxt" id="caphd">"I stand here today, grateful for the diversity of my heritage, 
       aware that my parents' dreams"</h2>
            <div class="tusr-img">
               <img src="images/testi.jpg">
                <h5>Adhi</h5>
            </div>
      </div>
        <div class="ban"><img id="bimg" src="quotes/images/dw.jpg" class="" id="ban2">
            <!--<div class="butbox"><a class="qut"  href="contact.html" >Get a quote</a><a href="socialevent.html" class="read">Read more</a></div>-->
        <div class="sidebg"></div>
    <h2 class="hdtxt" id="caphd">"I stand here today, grateful for the diversity of my heritage, 
       aware that my parents' dreams"</h2>
             <div class="tusr-img">
               <img src="images/testi.jpg">
                  <h5>Adhi</h5>
            </div>
        </div>
    <div class="switch">
       <img src="quotes/images/left.svg" class="prev" id="prev">
       <img src="quotes/images/right.svg" class="nxt" id="nxt">
    </div>
    </div>
    
<div id="page" class="site">

	<a class="skip-link screen-reader-text" href="#content"></a>

	<header id="masthead" class="site-header">

		<div class="ish-container-fluid clrchng">
			<div class="ish-container-inner">
				<div class="ish-row">

					<div class="ish-header">

						<!-- Main Logo & Tagline -->
						<div class="ish-logo-container ish-txt-color3">
							<a href="index.php"><span class="ish-logo-box"><span class="ish-logo-middle"><img src="images/logo1.svg" class="ish-logo" alt="Out of Best" /></span></span></a>
							<!--<span class="ish-theme-tagline ish-vertical">Unique Portfolio</span>-->
						</div>

						<!-- Menu open Button -->
						<div class="ish-menu-container ish-txt-color3">
							<a href="#"><span class="ish-icon-nav"><i class="ish-icon-menu"></i></span><span class="ish-menu-desc ish-vertical">Menu</span></a>
						</div>

					</div>

					<div class="site-branding" style="display:none;">
						<h1 class="site-title">When <span>Love</span><br> &amp; <span>Passion</span> meet</h1>
						<h2 class="site-subtitle">beautiful <span>things</span> start to <span>work</span>!</h2>
						<p class="site-description"><span>You don't believe?</span></p>
					</div><!-- .site-branding -->
				</div>

				<!-- Menu Container -->
				<div class="ish-navigation">

					<!-- Menu Decoration -->
					<div class="ish-nav-bg ish-theme-rotate"></div>

					<!-- Close Button -->
					<a href="#" class="ish-nav-close"><i class="ish-icon-cancel-1"></i><span>Close</span></a>

					<div class="ish-nav-container-bg">
						<div class="ish-nav-container">

							<!-- Menu: Logo & Tagline -->
							<div class="ish-widget-element">
								<a href="index.html"><img src="images/logo1.svg" class="ish-logo-widget" alt="Out of best" /></a>
								<!--<div class="ish-tagline-widget ish-txt-color1">Unique Portfolio</div>-->
							</div>

							<!-- Menu: Main Navigation -->
								<nav id="site-navigation" class="main-navigation ish-widget-element">
								<ul>
									<li class="ish-active-item"><a href="index.php"><span>Home</span></a></li>
									<li class="">
										<a href="service.php"><span>Service</span></a>
									</li>
									<li class="">
										<a href="quotes.php"><span>Quotes</span></a>
										<!--<ul>
											<li><a href="blog.html"><span>2 Columns Layout</span></a></li>
											<li><a href="blog-classic.html"><span>Classic Layout</span></a></li>
											<li><a href="blog-detail.html"><span>Post Detail</span></a></li>
										</ul>-->
									</li>
									<li class="">
										<a href="category.php"><span>Top Ten</span></a>
										<!--<ul>
											<li><a href="shortcodes.html"><span>Typography &amp; Shortcodes</span></a></li>
											<li><a href="about.html"><span>About Me</span></a></li>
											<li><a href="team.html"><span>Our Team</span></a></li>
											<li><a href="search-results.html"><span>Search Results</span></a></li>
											<li><a href="404.html"><span>404 - Not Found</span></a></li>
										</ul>-->
									</li>
									<li class="">
										<a href="about.php"><span>About</span></a>
										<!--<ul>
											<li><a href="contact.html"><span>Google Map Contact</span></a></li>
											<li><a href="contact-alt.html"><span>No Map Contact</span></a></li>
										</ul>-->
									</li>
									<li><a href="contact.php" ><span>Contact</span></a></li>
								</ul>
							</nav>

							<!-- Menu: Search Form -->
							<!--<form role="search" method="get" id="ish-search-nav-form" class="ish-search-form ish-widget-element" action="search-results.html">
								<div>
									<p><input type="text" value="" name="ish-search-nav" id="ish-search-nav" class="ish-search-nav" placeholder="Search"></p>
									<button type="submit" id="ish-search-nav-submit" class="ish-search-submit"><i class="ish-icon-search"></i></button>
								</div>
							</form>-->

							<!-- Menu: Social icons -->
							<div class="ish-social-box ish-widget-element ish-row">
								<span class="ish-col-xs-4 ish-twitter"><a href="#"><i class="ish-icon-twitter"></i></a></span>
								<span class="ish-col-xs-4 ish-behance"><a href="#"><i class="ish-icon-behance"></i></a></span>
								<span class="ish-col-xs-4 ish-dribbble"><a href="#"><i class="ish-icon-dribbble"></i></a></span>
								<span class="ish-col-xs-4 ish-instagram"><a href="#"><i class="ish-icon-instagram"></i></a></span>
								<span class="ish-col-xs-4 ish-gplus"><a href="#"><i class="ish-icon-gplus"></i></a></span>
								<span class="ish-col-xs-4 ish-facebook"><a href="#"><i class="ish-icon-facebook"></i></a></span>
							</div>

							<!-- Menu: About Template -->
							<!--<div class="ish-widget-element">
								<p>Another amazing template by <a href="http://ishyoboy.com" target="_blank" class="ish-underline">IshYoBoy.com</a></p>
							</div>-->

						</div>
					</div> <!-- .ish-nav-container-bg-->
				</div><!-- .ish-navigation -->

			</div>

		</div>

		<div class="ish-decor-container clrcon"><div class="ish-decor-bottom ish-theme-rotate "></div></div>


	</header><!-- #masthead -->
    <!--ser-->
    <!--slider-->
    <!--slider-->
    

    <!--slider-end-->
    <!--slider-->
    
     <div class="frmgrp-cnt">
        
        <div class="bxsh">
        
        <div class="frm-contr">
            <div class="frmfield">
                <form id="application_form_validated" action=""
      method="POST"   novalidate="novalidate" > 
                     <input type="hidden" name="_next" value="" />
                    
                    <h1 class="frm-tit">Drop your detials, we get back to you.</h1>              <!--frm1-end-->                    <div class="frm-con">						<div class="frm">							<input type="text" name="name" value="" placeholder="Name" class="usernme">						</div>						<div class="frm">							<div id="clet23" class="date_frm"><!--<input type="date" name="date" placeholder="date of birth" ><input  placeholder=""  type="date" name="date">-->							<input type="text" name="place" value="" placeholder="Place" class="usernme">							</div>							<!--<input type="date" name="date" placeholder="Date of birth" >-->						</div>                    </div> 
                    <!--frm1-end-->
                    <!--frm2-->
                    <div class="frm-con">						<div class="frm">							<input type="email" name="Email Id" value="" placeholder="Email Id" class="usernme">						</div>						<div id="cletf2">							<input type="tel" name="mobile" value="" placeholder="Mobile" class="usernme">						</div>                    </div>
                    <!--frm2 end-->
                        <!--frm3-->                   
                    <!--frm3 end-->
                          
                    <!--frm-4.1-->
                    <div class="frm-con">
                    <!--<div class="frm">
                      <div  id="cletf2" class="f3">							<select class="want_ex"  name="Intrested Field" style="" >								<option value="volvo" disabled selected >Intrested Field</option>								<option value="oc" >Engineering</option>								<option value="bc">Arts & Science</option>								<option value="mbc">For Phd</option>																															</select>						</div>
                    </div>-->
                        <!--hidden form-->
                   <!-- <div class="frm hfrm" style="visibility: hidden">
                       <input type="email" name="email" value="" placeholder="EMail ID" class="usernme">
                    </div>-->
                        <!--hidden form-->
                    </div>

                    <!--frm-4.1-->
                     <!--frm5-->
                    
                    <!--frm5 end-->
                    <!--frm6-->
                    <div class="frm-con">
                    <div class="frm">
                      <textarea type="textarea" name="Message" value="" placeholder="Message to Out of best" class="usernme" style="width:100%;"></textarea>
                    </div>
                    </div>
                    <!--frm6 end-->
                    <div class="subcon">
                    <input type="submit" name="submit" class="sub-mit">
                        </div>
                </form>
            </div>
        </div>
            <div class="cnt-img">
                 
                <div class="cnt-conwi">
                    <h1>Out of best is one stop platform for all your event needs</h1>
                    <p>Come on! Let make your event sound big.</p>
                    <p></p>
            <!--    <div class="flttr1"></div>-->
                </div>
            </div>
    <!--form-tag-->
            </div>
        </div>
    <!--footer-->
    <footer id="colophon" class="site-footer">

		<!-- FOOTER WIDGETS GO HERE -->
		<div class="ish-decor-container">
			<div class="ish-decor-top ish-theme-rotate ish-bg-color2"></div>
		</div>

		<div class="ish-container-fluid ish-bg-color2">
			<div class="ish-container-inner">
				<div class="ish-row">

					<div class="ish-footer ish-col-xs-offset-1 ish-col-xs-10">

						<div class="ish-widget-element">
							<a href="index.php"><img src="images/logo1.svg" class="ish-logo-widget" alt="QUSQ logo" /></a>
						</div>

						<!--<div class="ish-widget-element">
							<div class="ish-tagline-widget ish-txt-color3">Unique Portfolio</div>
						</div>-->

						<div class="ish-social-box ish-widget-element ish-row ish-center-xs">
							<span class="ish-col-xs-4 ish-col-sm-1 ish-twitter"><a href="#"><i class="ish-icon-twitter"></i></a></span>
							<span class="ish-col-xs-4 ish-col-sm-1 ish-behance"><a href="#"><i class="ish-icon-behance"></i></a></span>
							<span class="ish-col-xs-4 ish-col-sm-1 ish-dribbble"><a href="#"><i class="ish-icon-dribbble"></i></a></span>
							<span class="ish-col-xs-4 ish-col-sm-1 ish-instagram"><a href="#"><i class="ish-icon-instagram"></i></a></span>
							<span class="ish-col-xs-4 ish-col-sm-1 ish-gplus"><a href="#"><i class="ish-icon-gplus"></i></a></span>
							<span class="ish-col-xs-4 ish-col-sm-1 ish-facebook"><a href="#"><i class="ish-icon-facebook"></i></a></span>
						</div>

						<!--<div class="site-info ish-legals ish-widget-element">
						<a href="#" class="ish-underline">Qusq</a> Theme
						<span class="ish-separator">~</span>
						Proudly powered by <a href="https://wordpress.org/" target="_blank" class="ish-underline">WordPress</a>
						<span class="ish-separator">~</span>
						Created by <a href="http://ishyoboy.com" target="_blank" class="ish-underline">IshYoBoy.com</a>
					</div>
-->
					</div>

					<div class="ish-back-to-top ish-widget-element ish-col-xs-1">
						<a href="#page" class="ish-txt-color3"><span>Back to Top</span><i class="ish-icon-right-small"></i></a>
					</div>

				</div>
			</div>
		</div>

	</footer><!-- #colophon -->
    </div>
    <!--1-->
    
    <!--footer-->
    
<!--footer-->
 <script src="main/main.js" type="text/javascript"></script>
 <script src="quotes/quotes.js" type="text/javascript"></script>
 
 <script src="bootstrap/js/jquery.min.js" type="text/javascript"></script>
 <script src="main/vendor/AnimOnScroll.js" type="text/javascript"></script>
 <script src="main/vendor/plugins.js" type="text/javascript"></script>
</body>
</html>