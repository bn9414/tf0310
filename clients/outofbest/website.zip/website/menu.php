<?php

								<ul>
									<li class="ish-active-item"><a href="index.php"><span>Home</span></a></li>
									<li class="">
										<a href="service.php"><span>Service</span></a>
									</li>
									<li class="">
										<a href="quotes.php"><span>Quotes</span></a>
										
									</li>
									<li class="">
										<a href="category.php"><span>Top Ten</span></a>
										
									</li>
									<li class="">
										<a href="about.php"><span>About</span></a>
										
									</li>
									<li><a href="contact.php" ><span>Contact</span></a></li>
								</ul>
                                    
							
?>